package Classes;

public interface University {

    String getUniversityName();

    void setUniversityName(String universityName);

    String getUniversityAddress();

    void setUniversityAddress(String UniversityAddress);
}
